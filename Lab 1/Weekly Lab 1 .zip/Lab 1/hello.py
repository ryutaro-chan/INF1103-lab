print("=============")
print("Welcome Here")
print("My first post!")
print("=============")
username = "cool creator" 
bio = "Fun blogger"
followers = 100
print("Username:", username)
print("Bio:", bio)
print("Followers:", followers)
followers=100
followers += 50
print("Day 1:", followers)
followers += 20
print("Day 2:", followers)
followers -= 10
print("Day3:", followers)
username = input("Enter Username: ")
age = input("Enter age: ")
category = input("Enter Content Category: ")
print("\nInstagram Profile")
print("==========")
print("Username:", username)
print("Age:", age)
print("Category:", category)
username = input("Enter Username: ")
age = int(input("Enter Age: "))
category = input("Enter Content Category: ")
print("\nInstagramProfile")
print("===============")
print("Username:", username)
print("Age:", age)
print("Category:", category)
if age>40 and category == "fun":
    print("You are old what is fun for you??")